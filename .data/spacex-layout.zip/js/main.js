var rellax = new Rellax(".rocket");
if (document.body.clientWidth < 576) {
	rellax.destroy();
}

